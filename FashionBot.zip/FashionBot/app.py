"""
Smart AI Fashion Predictor – Flask Application
"""
import os
import json
import sqlite3
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, g

# Ensure model dir is importable
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "model"))
from predictor import predict

app = Flask(__name__)
DATABASE = os.path.join(os.path.dirname(__file__), "database.db")

# ──────────────────────────────────────────────────────────
# DATABASE HELPERS
# ──────────────────────────────────────────────────────────

def get_db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, "_database", None)
    if db is not None:
        db.close()

def init_db():
    with app.app_context():
        db = get_db()
        db.execute("""
            CREATE TABLE IF NOT EXISTS predictions (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                name        TEXT,
                gender      TEXT,
                height      TEXT,
                skin_tone   TEXT,
                health      TEXT,
                event       TEXT,
                location    TEXT,
                pref_colors TEXT,
                result      TEXT,
                created_at  TEXT
            )
        """)
        db.commit()

# ──────────────────────────────────────────────────────────
# ROUTES
# ──────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict_route():
    name         = request.form.get("name", "").strip() or "Guest"
    gender       = request.form.get("gender", "boy")
    height       = request.form.get("height", "medium")
    skin_tone    = request.form.get("skin_tone", "medium")
    health_raw   = request.form.getlist("health")          # list of strings
    event        = request.form.get("event", "casual")
    location     = request.form.get("location", "casual")
    pref_colors  = request.form.getlist("preferred_colors")  # list of strings

    # Normalise health – if "none" is selected or list is empty
    if not health_raw or "none" in health_raw:
        health_raw = ["none"]

    inputs = {
        "gender":           gender,
        "height":           height,
        "skin_tone":        skin_tone,
        "health":           health_raw,
        "event":            event,
        "location":         location,
        "preferred_colors": pref_colors,
    }

    result = predict(inputs)

    # Save to DB
    db = get_db()
    db.execute(
        """INSERT INTO predictions
           (name, gender, height, skin_tone, health, event, location, pref_colors, result, created_at)
           VALUES (?,?,?,?,?,?,?,?,?,?)""",
        (
            name, gender, height, skin_tone,
            json.dumps(health_raw),
            event, location,
            json.dumps(pref_colors),
            json.dumps(result),
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        ),
    )
    db.commit()

    user_info = {
        "name":          name,
        "gender":        gender.capitalize(),
        "height":        height.capitalize(),
        "skin_tone":     skin_tone.capitalize(),
        "health":        [h.title() for h in health_raw],
        "event":         event.title(),
        "location":      location.title(),
        "pref_colors":   pref_colors,
    }
    return render_template("result.html", result=result, user=user_info)


@app.route("/history")
def history():
    db = get_db()
    rows = db.execute(
        "SELECT * FROM predictions ORDER BY created_at DESC LIMIT 20"
    ).fetchall()
    records = []
    for row in rows:
        r = dict(row)
        r["result"]      = json.loads(r["result"])
        r["health"]      = json.loads(r["health"])
        r["pref_colors"] = json.loads(r["pref_colors"])
        records.append(r)
    return render_template("history.html", records=records)


@app.route("/clear_history", methods=["POST"])
def clear_history():
    db = get_db()
    db.execute("DELETE FROM predictions")
    db.commit()
    return redirect(url_for("history"))


# ──────────────────────────────────────────────────────────
# ENTRY POINT
# ──────────────────────────────────────────────────────────

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
