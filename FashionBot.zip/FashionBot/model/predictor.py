"""
Smart AI Fashion Predictor – Rule-Based Prediction Engine
"""

# ──────────────────────────────────────────────────────────
# OUTFIT RULES DATABASE
# ──────────────────────────────────────────────────────────

OUTFITS = {
    # (gender, event) → outfit
    ("boy", "wedding"):      "Sherwani with Churidar & Dupatta",
    ("boy", "festival"):     "Kurta-Pajama with Nehru Jacket",
    ("boy", "party"):        "Slim-fit Chinos with Printed Casual Shirt",
    ("boy", "office"):       "Formal Trousers with Crisp Oxford Shirt",
    ("boy", "interview"):    "Navy Blazer with White Formal Shirt & Formal Trousers",
    ("boy", "college"):      "Jeans with Polo T-Shirt or Casual Shirt",
    ("boy", "beach"):        "Board Shorts with Light Linen Shirt",
    ("boy", "temple"):       "Dhoti with Traditional Silk Shirt / Kurta-Pajama",
    ("boy", "birthday"):     "Chinos with Casual Graphic Tee & Sneakers",
    ("boy", "conference"):   "Business Casual – Chinos, Formal Shirt & Blazer",
    ("boy", "casual"):       "Jeans with T-Shirt and Sneakers",
    ("girl", "wedding"):     "Silk Saree / Lehenga Choli with Gold Embroidery",
    ("girl", "festival"):    "Traditional Anarkali Kurta / Ghagra Choli",
    ("girl", "party"):       "Bodycon Dress / Jumpsuit with Bold Accessories",
    ("girl", "office"):      "Formal Pencil Skirt with Blouse / Formal Salwar Suit",
    ("girl", "interview"):   "Formal Straight-cut Trouser with Professional Blazer & Blouse",
    ("girl", "college"):     "Casual Kurti with Jeans / Sundress",
    ("girl", "beach"):       "Flowy Maxi Dress / Cover-up with Bikini",
    ("girl", "temple"):      "Cotton Saree / Salwar Kameez with Dupatta",
    ("girl", "birthday"):    "Skater Dress / Casual Midi Dress with Heels",
    ("girl", "conference"):  "Formal Pantsuit / Saree / Business Kurta with Trousers",
    ("girl", "casual"):      "Casual Kurti with Palazzos or Jeans",
}

FABRICS = {
    "skin allergy":     ("100% Soft Cotton or Bamboo Fabric", "Avoid synthetic fabrics, polyester, wool, and rough textures"),
    "eczema":           ("Organic Cotton or Silk (hypoallergenic)", "Avoid nylon, spandex, and tight-fitting synthetic clothes"),
    "sweating issues":  ("Breathable Cotton, Linen or Moisture-wicking Fabric", "Avoid dark heavy fabrics that trap heat"),
    "sensitive skin":   ("Soft Cotton-Jersey or Tencel/Lyocell", "Avoid rough seams, itchy wool, or stiff starched fabric"),
    "none":             ("Cotton, Linen, Chiffon or Polyester blend (based on occasion)", "No specific restrictions – choose comfort"),
}

COLORS = {
    "fair":   {
        "best":   ["Pastel Pink", "Lavender", "Mint Green", "Powder Blue", "Rose Gold", "Off-White", "Navy Blue"],
        "avoid":  ["Neon Yellow", "Fluorescent Shades"],
        "tip":    "Light pastels and soft jewel tones complement fair skin beautifully.",
    },
    "medium": {
        "best":   ["Terracotta", "Mustard Yellow", "Teal", "Olive Green", "Warm Burgundy", "Coral", "Ivory"],
        "avoid":  ["Very pale pastels that wash out medium tones"],
        "tip":    "Earth tones and warm jewel shades enhance medium skin glow.",
    },
    "dark":   {
        "best":   ["Bright Orange", "Cobalt Blue", "Magenta", "Hot Pink", "Emerald Green", "Red", "Gold"],
        "avoid":  ["Dull browns and greys that blend into skin"],
        "tip":    "Bold, vibrant, and warm hues make dark skin tone radiate confidence.",
    },
}

PATTERNS = {
    "short":  {
        "style":  "Vertical Stripes & Monochrome Looks",
        "tip":    "Wear single-colour outfits from head to toe to create an elongated appearance. High-waisted bottoms add perceived height.",
        "avoid":  "Horizontal stripes, oversized silhouettes, and baggy clothes.",
    },
    "medium": {
        "style":  "All Patterns Work Well",
        "tip":    "You can pull off any pattern or silhouette. Experiment with florals, checks, or abstract prints.",
        "avoid":  "None specifically – go with what flatters your body shape.",
    },
    "tall":   {
        "style":  "Layered Outfits & Horizontal or Mixed Patterns",
        "tip":    "Embrace layers, wide-leg trousers, and bold horizontal prints to balance your height. Cropped tops pair well with high-waisted bottoms.",
        "avoid":  "Overly elongating vertical stripes from head to toe.",
    },
}

ACCESSORIES = {
    ("girl", "wedding"):     ["Statement Necklace / Choker", "Maang Tikka", "Jhumka Earrings", "Bangles / Kangan", "Embroidered Clutch", "Heels"],
    ("girl", "festival"):    ["Oxidized Jewellery", "Kolhapuri Chappals", "Bindi", "Fabric Potli Bag"],
    ("girl", "party"):       ["Hoop Earrings", "Strappy Heels", "Mini Clutch", "Layered Bracelets"],
    ("girl", "office"):      ["Stud Earrings", "Watch", "Formal Tote Bag", "Low Heels / Flats"],
    ("girl", "interview"):   ["Minimal Stud Earrings", "Watch", "Structured Handbag", "Formal Flats / Pumps"],
    ("girl", "college"):     ["Hoop Earrings", "Sneakers", "Sling Bag", "Casual Watch"],
    ("girl", "beach"):       ["Sunglasses", "Wide-Brim Hat", "Flip-Flops", "Beach Tote", "Anklet"],
    ("girl", "temple"):      ["Simple Gold Earrings", "Bindi", "Bangles", "Comfortable Flats"],
    ("girl", "birthday"):    ["Statement Earrings", "Block Heels", "Party Clutch", "Layered Necklace"],
    ("girl", "conference"):  ["Stud Earrings", "Formal Handbag", "Watch", "Comfortable Formal Shoes"],
    ("girl", "casual"):      ["Casual Sneakers", "Sling Bag", "Sunglasses", "Minimal Jewelry"],
    ("boy", "wedding"):      ["Mojri / Jutis", "Pocket Square", "Turban / Safa (optional)", "Stole / Dupatta", "Watch"],
    ("boy", "festival"):     ["Kolhapuri Chappals", "Stole", "Casual Watch"],
    ("boy", "party"):        ["Loafers / White Sneakers", "Casual Watch", "Belt", "Sunglasses"],
    ("boy", "office"):       ["Leather Oxford Shoes", "Formal Belt", "Watch", "Briefcase / Laptop Bag"],
    ("boy", "interview"):    ["Formal Oxford Shoes", "Leather Belt", "Watch", "Portfolio Bag"],
    ("boy", "college"):      ["Sneakers", "Casual Watch", "Backpack", "Cap (optional)"],
    ("boy", "beach"):        ["Flip-Flops", "Sunglasses", "Beach Bag", "Cap"],
    ("boy", "temple"):       ["Simple Chappals / Mojri", "Stole"],
    ("boy", "birthday"):     ["Clean Sneakers", "Casual Watch", "Crossbody Bag"],
    ("boy", "conference"):   ["Formal Shoes", "Watch", "Leather Belt", "Laptop Bag"],
    ("boy", "casual"):       ["Sneakers", "Watch", "Backpack", "Cap"],
}

LOCATION_TIPS = {
    "beach":    "Choose lightweight, quick-dry fabrics. Cover up against UV rays. Sand-friendly footwear is a must.",
    "office":   "Keep it professional and minimal. Avoid loud prints or revealing clothing.",
    "college":  "Comfort is key. Mix casual and smart-casual styles. Carry a functional backpack.",
    "temple":   "Dress modestly. Cover shoulders and knees. Remove footwear when required.",
    "party":    "Have fun with your look! Bold colours, statement pieces, and trendy styles are welcome.",
    "wedding":  "Dress elegantly. Opt for ethnic or semi-formal wear. Avoid white or black if culturally sensitive.",
    "festival": "Embrace vibrant colours, traditional motifs, and ethnic wear.",
    "interview": "Dress to impress conservatively. Stick to neutral, well-pressed, and clean attire.",
    "conference": "Smart business casual or formal. Prioritise comfort over the long day.",
    "birthday": "Fun and festive! Express your personality through colour and accessories.",
    "casual":   "Comfort meets style. Mix & match basics. Layer up if needed.",
}

# ──────────────────────────────────────────────────────────
# MAIN PREDICT FUNCTION
# ──────────────────────────────────────────────────────────

def predict(inputs: dict) -> dict:
    gender     = inputs.get("gender", "boy").lower()
    height     = inputs.get("height", "medium").lower()
    skin_tone  = inputs.get("skin_tone", "medium").lower()
    health     = [h.lower() for h in inputs.get("health", [])]
    event      = inputs.get("event", "casual").lower()
    location   = inputs.get("location", "casual").lower()
    pref_color = inputs.get("preferred_colors", [])

    # 1. Outfit
    outfit = OUTFITS.get((gender, event)) or OUTFITS.get((gender, location))
    if not outfit:
        outfit = "A stylish, occasion-appropriate outfit tailored to your preferences"

    # 2. Fabric (pick strongest health condition)
    fabric_rec = FABRICS["none"]
    for cond in ["eczema", "skin allergy", "sensitive skin", "sweating issues"]:
        if cond in health:
            fabric_rec = FABRICS[cond]
            break
    fabric_name, fabric_note = fabric_rec

    # 3. Colors
    skin_data   = COLORS.get(skin_tone, COLORS["medium"])
    best_colors = skin_data["best"]
    avoid_colors= skin_data["avoid"]
    color_tip   = skin_data["tip"]
    if pref_color:
        best_colors = pref_color + [c for c in best_colors if c not in pref_color]

    # 4. Pattern
    pattern_data = PATTERNS.get(height, PATTERNS["medium"])
    pattern_style  = pattern_data["style"]
    pattern_tip    = pattern_data["tip"]
    pattern_avoid  = pattern_data["avoid"]

    # 5. Accessories
    accessories = ACCESSORIES.get((gender, event)) or ACCESSORIES.get((gender, location)) or []

    # 6. Location-specific tip
    loc_tip = LOCATION_TIPS.get(event) or LOCATION_TIPS.get(location) or ""

    # 7. Styling tips
    styling_tips = [
        f"🎨 Color: {color_tip}",
        f"📐 Silhouette: {pattern_tip}",
        f"🧵 Fabric: {'Opt for ' + fabric_name} because it suits your skin needs.",
        f"📍 Venue: {loc_tip}",
    ]
    if "sweating issues" in health:
        styling_tips.append("💧 Moisture Control: Wear moisture-wicking inner layers and choose loose-cut silhouettes to stay fresh.")
    if pref_color:
        styling_tips.append(f"✨ Your preferred colour(s) {', '.join(pref_color)} work great – incorporate them into your accessories or statement piece.")

    # 8. Dos and Don'ts
    dos = [
        f"✅ Choose {fabric_name} for maximum comfort.",
        f"✅ Wear {', '.join(best_colors[:3])} — they complement your skin tone beautifully.",
        f"✅ Go for {pattern_style} in your outfit to flatter your {height} height.",
        f"✅ Dress appropriately for the {event} setting.",
        f"✅ Accessorise with: {', '.join(accessories[:3])}.",
    ]
    donts = [
        f"❌ Avoid: {fabric_note}.",
        f"❌ Steer clear of {', '.join(avoid_colors)} which can wash out your complexion.",
        f"❌ Avoid: {pattern_avoid}",
        "❌ Don't overdress or underdress — match the occasion's dress code.",
        "❌ Avoid heavily scented products that can trigger skin reactions on sensitive skin." if any(c in health for c in ["skin allergy","eczema","sensitive skin"]) else "❌ Don't compromise comfort for style — find the perfect balance.",
    ]

    return {
        "outfit":        outfit,
        "fabric":        fabric_name,
        "fabric_note":   fabric_note,
        "colors":        best_colors,
        "avoid_colors":  avoid_colors,
        "color_tip":     color_tip,
        "pattern":       pattern_style,
        "pattern_tip":   pattern_tip,
        "pattern_avoid": pattern_avoid,
        "accessories":   accessories,
        "styling_tips":  styling_tips,
        "dos":           dos,
        "donts":         donts,
        "location_tip":  loc_tip,
    }
