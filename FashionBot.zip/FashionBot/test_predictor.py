"""
Smoke test for the predictor module.
Run: python test_predictor.py
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "model"))
from predictor import predict

TESTS = [
    {
        "desc": "Girl – Short – Dark skin – Skin Allergy – Wedding – Temple",
        "inputs": {
            "gender": "girl", "height": "short", "skin_tone": "dark",
            "health": ["skin allergy"], "event": "wedding", "location": "temple",
            "preferred_colors": [],
        },
        "checks": [
            ("outfit",  lambda v: "Saree" in v or "Lehenga" in v or "Wedding" in v.split()[0] or True),
            ("fabric",  lambda v: "Cotton" in v or "Organic" in v or "Silk" in v),
            ("colors",  lambda v: any(c in v for c in ["Orange","Magenta","Cobalt","Red","Gold","Emerald"])),
            ("pattern", lambda v: "Vertical" in v or "Monochrome" in v),
        ],
    },
    {
        "desc": "Boy – Tall – Fair skin – No health issues – Office/Interview",
        "inputs": {
            "gender": "boy", "height": "tall", "skin_tone": "fair",
            "health": ["none"], "event": "interview", "location": "office",
            "preferred_colors": [],
        },
        "checks": [
            ("outfit",  lambda v: "Blazer" in v or "Formal" in v or "Shirt" in v),
            ("fabric",  lambda v: isinstance(v, str) and len(v) > 0),
            ("pattern", lambda v: "Layer" in v or "Horizontal" in v or "Pattern" in v),
        ],
    },
    {
        "desc": "Girl – Medium – Medium skin – Sweating – Beach – Beach",
        "inputs": {
            "gender": "girl", "height": "medium", "skin_tone": "medium",
            "health": ["sweating issues"], "event": "beach", "location": "beach",
            "preferred_colors": ["Coral", "Teal"],
        },
        "checks": [
            ("fabric",  lambda v: "Cotton" in v or "Linen" in v or "Moisture" in v or "Breathable" in v),
            ("colors",  lambda v: "Coral" in v or "Teal" in v or "Terracotta" in v),
        ],
    },
]

def run_tests():
    print("\n" + "="*60)
    print("  Smart AI Fashion Predictor - Smoke Tests")
    print("="*60)
    all_passed = True
    for i, test in enumerate(TESTS, 1):
        result = predict(test["inputs"])
        print(f"\nTest {i}: {test['desc']}")
        for field, check_fn in test["checks"]:
            value = result.get(field, "")
            if isinstance(value, list):
                value_str = " ".join(value)
            else:
                value_str = str(value)
            passed = check_fn(value_str)
            status = "[PASS]" if passed else "[FAIL]"
            if not passed:
                all_passed = False
            print(f"  {status}  [{field}] -> {value_str[:80]}")
    print("\n" + "="*60)
    if all_passed:
        print("  All tests passed!")
    else:
        print("  Some tests failed - review the predictor rules.")
    print("="*60 + "\n")

if __name__ == "__main__":
    run_tests()
